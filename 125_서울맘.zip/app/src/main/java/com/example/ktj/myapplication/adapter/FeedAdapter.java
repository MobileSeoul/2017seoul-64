package com.example.ktj.myapplication.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.ViewTarget;
import com.example.ktj.myapplication.R;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by xowns on 2017-08-22.
 */

public class FeedAdapter extends BaseAdapter{

    private Context mContext;
    private ArrayList<String> imgList;
    private ArrayList<String> subwayList;
    LayoutInflater inflater;

    public FeedAdapter(Context c, ArrayList<String> imgList) {
        mContext = c;
        this.imgList = imgList;
        inflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);

        subwayList = new ArrayList<String>(Arrays.asList("종로 3가", "성수", "동대문", "강변",
                "시청", "잠실", "신설동", "삼성", "서울", "강남", "구파발", "신림", "독립문", "대림", "옥수", "영등포구청", "고속터미널",
                "신촌", "양재",  "동대문역사", "도곡", "사당", "노원", "미아사거리", "길음", "이촌"));
    }

    @Override
    public int getCount() {
        return imgList.size();
    }

    @Override
    public Object getItem(int position) {
        return imgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View layout;

        layout = new View(mContext);

        layout = inflater.inflate(R.layout.subway_category_item, null);

        ImageView subway_img = (ImageView)layout.findViewById(R.id.img_subway);
        TextView subway_tv  = (TextView) layout.findViewById(R.id.tv_subway);

        subway_tv.setText(subwayList.get(position));
        if(position == 0 || position == 2 || position == 4 || position == 6 || position == 8) { //1호선
            subway_tv.setTextColor(Color.parseColor("#00309c"));
        }

        if(position == 1 || position == 3 || position == 5 || position == 7 || position == 9 || position == 11 || //2호선
                position == 13 || position == 15 || position == 17 || position == 19 || position == 21) {
            subway_tv.setTextColor(Color.parseColor("#2eb51d"));
        }

        if(position == 10 || position == 12 || position == 14 || position == 16 || position == 18 || position == 20) { //3호선
            subway_tv.setTextColor(Color.parseColor("#f17f00"));
        }

        if(position == 22 || position == 23 || position == 24 || position == 25) { //4호선
            subway_tv.setTextColor(Color.parseColor("#1c7db5"));
        }


        Glide.with(mContext).load(imgList.get(position)).fitCenter().into(new ViewTarget<ImageView, GlideDrawable>(subway_img) {
            @Override
            public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {

                ImageView myView = this.view;
                myView.setBackground(resource);
            }
        });

        return layout;
    }
}
