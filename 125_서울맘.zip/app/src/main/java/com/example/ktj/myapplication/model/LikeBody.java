package com.example.ktj.myapplication.model;

import java.util.List;

/**
 * Created by xyom on 2017-08-05.
 */

public class LikeBody {
    String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<Like> getData() {
        return data;
    }

    public void setData(List<Like> data) {
        this.data = data;
    }

    List<Like> data;
}
