package com.example.ktj.myapplication.api;

/**
 * Created by xowns on 2017-08-21.
 */

public class Api {

    public static final String Happy_Card_Url = "http://openapi.seoul.go.kr:8088/6741545978786f773130324f764d7566/json/InfoHappycard/1/1000/";
    public static final String Happy_Card_Url2 = "http://openapi.seoul.go.kr:8088/6741545978786f773130324f764d7566/json/InfoHappycard/1001/2000/";
    public static final String Happy_Card_Url3 = "http://openapi.seoul.go.kr:8088/6741545978786f773130324f764d7566/json/InfoHappycard/2001/3000/";
    public static final String Happy_Card_Url4 = "http://openapi.seoul.go.kr:8088/6741545978786f773130324f764d7566/json/InfoHappycard/3001/3264/";
    public static final String Subway_Feedingroom = "http://xowns9418.cafe24.com/feedingroom/subway.php";

}
