package com.example.ktj.myapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.ViewTarget;
import com.example.ktj.myapplication.R;


import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by xowns on 2017-08-21.
 */

public class GuAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<String> imgList;
    LayoutInflater inflater;
    private ArrayList<String> guList;

    public GuAdapter(Context c, ArrayList<String> imgList) {
        mContext = c;
        this.imgList = imgList;
        inflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);

        guList = new ArrayList<String>(Arrays.asList("강남구", "강동구", "강북구", "강서구", "관악구",
                "광진구", "구로구", "금천구", "노원구", "도봉구", "동대문구", "동작구",
                "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구",
                "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"));
    }

    @Override
    public int getCount() {
        return imgList.size();
    }

    @Override
    public Object getItem(int position) {
        return imgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

             View layout;

            layout = new View(mContext);

            layout = inflater.inflate(R.layout.gu_layout_item, null);

            if(position == 25) return layout; // 구 종류의 마지막 빈 layout

            ImageView gu_img = (ImageView)layout.findViewById(R.id.img_gu);
            TextView gu_tv  = (TextView) layout.findViewById(R.id.tv_gu);

            gu_tv.setText(guList.get(position));

            Glide.with(mContext).load(imgList.get(position)).fitCenter().into(new ViewTarget<ImageView, GlideDrawable>(gu_img) {
                @Override
                public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {

                    ImageView myView = this.view;
                    myView.setBackground(resource);
                }
            });

        return layout;
    }
}

