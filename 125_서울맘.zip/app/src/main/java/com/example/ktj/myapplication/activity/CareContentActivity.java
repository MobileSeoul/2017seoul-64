package com.example.ktj.myapplication.activity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ktj.myapplication.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by dhyeok on 2017-08-14.
 */

public class CareContentActivity extends AppCompatActivity {
    ArrayList<ContentStruct> content; //기사 내용을 태그별로 List에 넣음

    String URL;
    String title;

    //View
    TextView tv_title;
    TextView tv_status_title;
    TextView tv_article_date;
    LinearLayout ll_dynamic_area;
    ProgressDialog progressDialog;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.care_article_content);

        //기사 url에다가 전 페이지에서 받은 index값을 추가해줌
        URL = getIntent().getStringExtra("URL");

        content = new ArrayList<>();

        tv_title = (TextView) findViewById(R.id.tv_article_title);
        ll_dynamic_area = (LinearLayout) findViewById(R.id.ll_dynamic_area);
        imageView = (ImageView) findViewById(R.id.back_image);
        progressDialog = ProgressDialog.show(this, "", "불러오는중");
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tv_status_title = (TextView) findViewById(R.id.tv_status_title);
        tv_article_date = (TextView) findViewById(R.id.tv_article_date);

        tv_article_date.setText("기사입력 : " + getIntent().getStringExtra("DATE"));

        //크롤링 시작
        CareContentActivity.JsoupAsyncTask jsoupAsyncTask = new CareContentActivity.JsoupAsyncTask();
        jsoupAsyncTask.execute();
    }

    private class ContentStruct {
        private int type;
        private String content;
        private TextView textView;
        private ImageView imageView;
        private Bitmap bitmap;

        //생성자에서 type별로 content를 저장
        public ContentStruct(int type, String content) {
            this.type = type;
            this.content = content;

            if (type == 1) {//이미지
                imageView = new ImageView(CareContentActivity.this);
                imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                imageView.setAdjustViewBounds(true);

                final String strURL = this.content;
                Thread mThread = new Thread() {

                    @Override
                    public void run() {

                        try {
                            URL url = new URL(strURL);

                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setDoInput(true);
                            conn.connect();

                            InputStream is = conn.getInputStream();
                            bitmap = BitmapFactory.decodeStream(is);

                        } catch (IOException ex) {

                        }
                    }
                };

                mThread.start(); // 웹에서 이미지를 가져오는 작업 스레드 실행.

                try {
                    mThread.join();
                    imageView.setImageBitmap(bitmap);
                } catch (InterruptedException e) {

                }

            } else {
                textView = new TextView(CareContentActivity.this);
                textView.setText(this.content);
                textView.setTextSize(16);
                //textView.setTextColor(0xffffff);
            }
        }

        public TextView getTextView() {
            return textView;
        }

        public ImageView getImageView() {
            return imageView;
        }

    }


    private class JsoupAsyncTask extends AsyncTask<Void, Void, Void> {

        public void recursion(Elements es) {

            for (Element e : es) {
                recursion(e.children());

                if (e.tag().toString().equals("img")) {
                    ContentStruct data = new ContentStruct(1, e.attr("src"));
                    e.remove();
                    content.add(data);

                } else {
                    if (!e.text().equals("") && !e.text().equals("\n")) {
                        ContentStruct data = new ContentStruct(2, e.text() + '\n');
                        content.add(data);
                        e.remove();
                    }
                }
            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                Document doc = Jsoup.connect(URL).get();
                Elements board = doc.select(".boardView");
                title = board.select(".title").select("dd").text();

                Elements children = board.select(".cont").select("dd").first().children();

                recursion(children);

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            tv_title.setText(title);

            if (title.length() >= 20) {
                title = title.substring(0, 20);
                title += "...";
            }

            tv_status_title.setText(title);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            for (ContentStruct data : content) {
                if (data.type == 1) {
                    ll_dynamic_area.addView(data.getImageView(), layoutParams);
                } else {
                    ll_dynamic_area.addView(data.getTextView());
                }
                progressDialog.dismiss();
            }
        }
    }
}
