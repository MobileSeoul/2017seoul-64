package com.example.ktj.myapplication.model;

import java.io.Serializable;

/**
 * Created by xowns on 2017-08-21.
 */

public class Place implements Serializable{

    private  String CATEGORY;
    private  String COMPANY_NAME;
    private  String ADDR;
    private  String OFFICE_TEL;
    private  String SUPPORT;

    public Place(String CATEGORY, String COMPANY_NAME, String ADDR, String OFFICE_TEL, String SUPPORT) {

        this.CATEGORY =  CATEGORY;
        this.COMPANY_NAME = COMPANY_NAME;
        this.ADDR = ADDR;
        this.OFFICE_TEL = OFFICE_TEL;
        this.SUPPORT = SUPPORT;
    }

    public  String getCATEGORY() {
        return CATEGORY;
    }

    public  String getCompanyName() {
        return COMPANY_NAME;
    }

    public String getADDR() {
        return ADDR;
    }

    public  String getOfficeTel() {
        return OFFICE_TEL;
    }

    public String getSUPPORT() {
        return SUPPORT;
    }
}
