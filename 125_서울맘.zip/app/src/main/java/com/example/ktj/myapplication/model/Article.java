package com.example.ktj.myapplication.model;

import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Article {
    private LinearLayout ll;
    private String no;
    private String title;
    private String date;
    private String hits;
    private String idx;//url_idx
    private String img_url;
    String Json;

    static String url = "http://iseoul.seoul.go.kr/portal/info/boyukNewsView.do?idx=";


    public Article(String no, String title, String date, String hits, String idx, int tab_idx) {

        this.no = no;
        this.title = title;
        this.date = date;
        this.hits = hits;
        this.idx = idx;
        this.img_url = "http://52.78.211.151:3002/api/" + tab_idx + "/" + no;


        Thread mThread = new Thread() {


            @Override
            public void run() {
                Json = DownloadHtml(img_url);
                img_url = parsingJson_IPDATA(Json);
            }
        };

        mThread.start();

    }


    public String getImg_url() {
        return this.img_url;
    }

    public LinearLayout getLl() {
        return ll;
    }

    public void setLl(LinearLayout ll) {
        this.ll = ll;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHits() {
        return hits;
    }

    public void setHits(String hits) {
        this.hits = hits;
    }

    public String getIdx() {
        return idx;
    }

    public void setIdx(String idx) {
        this.idx = idx;
    }


    public String getUrl() {
        return url + idx;
    }


    static String DownloadHtml(String addr) {
        StringBuilder jsonHtml = new StringBuilder();
        try {
            URL url = new URL(addr);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            if (conn != null) {
                conn.setConnectTimeout(10000);
                conn.setUseCaches(false);

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    //Read Data From Web
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    for (; ; ) {

                        String line = br.readLine();
                        if (line == null) break;

                        jsonHtml.append(line + "\n");
                    }
                    br.close();
                }
                conn.disconnect();
            }
        } catch (Exception ex) {
            Log.e("jsonerr", "Error parsing json ");
        }
        return jsonHtml.toString();
    }

    public static String parsingJson_IPDATA(String Json_read) {
        String img_url = "";

        try {
            JSONObject jsonObject = new JSONObject(Json_read);
            System.out.println("jsonData : " + jsonObject.toString());

            img_url = jsonObject.getString("url");
            System.out.println("url : " + img_url);
        } catch (JSONException e) {
            Log.e("log_tag", "Error parsing data " + e.toString());

        }

        return img_url;
    }

}


