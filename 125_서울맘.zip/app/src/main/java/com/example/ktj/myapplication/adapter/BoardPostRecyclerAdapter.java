package com.example.ktj.myapplication.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.RetroService.LikeService;
import com.example.ktj.myapplication.RetroService.ReplyService;
import com.example.ktj.myapplication.model.Post;
import com.example.ktj.myapplication.model.Reply;
import com.example.ktj.myapplication.model.ReplyBody;
import com.example.ktj.myapplication.model.Result;
import com.example.ktj.myapplication.util.SharedPrefereneces;
import com.google.gson.JsonObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by xyom on 2017-08-05.
 */

public class BoardPostRecyclerAdapter extends RecyclerView.Adapter<BoardPostRecyclerAdapter.ViewHolder> {

    private List<Post> postList;
    private Context context;
    private String user_id;

    LinearLayout reply_layout;
    RecyclerView recyclerView;

    int reply_current_page=1;

    TextView p_category,p_title,p_writer,p_content,p_date,p_click_number,p_reply_more,p_reply_number;
    EditText p_edit_reply;
    Button p_edit_ok;
    LinearLayout p_reply_area;
    List<Reply> p_reply_list;
    String p_user_id="";

    String s_category,s_title,s_writer,s_content,s_date,s_click_number,s_post_id,s_reply;

    int ok=0;

    public BoardPostRecyclerAdapter() {
        super();
    }
    public BoardPostRecyclerAdapter(List<Post> items,String user_id,LinearLayout reply,RecyclerView recyclerView)
    {
        postList=items;
        this.user_id = user_id;
        reply_layout=reply;
        this.recyclerView=recyclerView;
    }

    public static String cutString(String str)
    {
        if(str.length()>=50)
            return str.substring(0,50)+"...";
        else
            return str;
    }


    @Override
    public BoardPostRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.board_list_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        Post post = postList.get(position);
        holder.writer.setText(post.getWriter());
        holder.date.setText(post.getDate());
        holder.click_number.setText(post.getLikeCount());
        holder.reply_number.setText(post.getReplyCount());
        holder.content.setText(cutString(post.getContent()));
        holder.title.setText(post.getTitle());
        holder.like.setTextColor(context.getResources().getColor(android.R.color.tab_indicator_text));

        if(post.getCategory().equals("1"))
            holder.cateText.setText("육아 고민");
        else
            holder.cateText.setText("잡담");

        holder.reply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                recyclerView.setVisibility(View.GONE);
                reply_layout.setVisibility(View.VISIBLE);
                Post item = getItemAt(holder.getAdapterPosition());
                ok=1;
                initReply(item);
                ok=0;
            }
        });

        LikeService likeService = LikeService.retrofit.create(LikeService.class);
        Call<Result> call = likeService.countPostLike(user_id,getItemAt(position).getPost_id());
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                if(response.body().getResult().equals("1"))
                    holder.like.setTextColor(Color.BLUE);

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

            }
        });

        holder.like.setOnClickListener(new View.OnClickListener() { // 좋아요
            @Override
            public void onClick(View view) {

                if(!user_id.equals("")) {
                    LikeService likeService = LikeService.retrofit.create(LikeService.class);
                    Call<Result> call = likeService.countPostLike(user_id, getItemAt(holder.getAdapterPosition()).getPost_id());
                    call.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            if (response.body().getResult().equals("1")) {

                                LikeService likeServices = LikeService.retrofit.create(LikeService.class);
                                Call<Result> calls = likeServices.undoLike(user_id, getItemAt(holder.getAdapterPosition()).getPost_id());
                                calls.enqueue(new Callback<Result>() {
                                    @Override
                                    public void onResponse(Call<Result> call, Response<Result> response) {
                                        holder.like.setTextColor(context.getResources().getColor(android.R.color.tab_indicator_text));
                                    }

                                    @Override
                                    public void onFailure(Call<Result> call, Throwable t) {

                                    }
                                });
                            } else {
                                LikeService likeServices = LikeService.retrofit.create(LikeService.class);
                                JsonObject jsonObject = new JsonObject();
                                jsonObject.addProperty("user_id", user_id);
                                jsonObject.addProperty("post_id", getItemAt(holder.getAdapterPosition()).getPost_id());
                                Call<Result> calls = likeServices.doLike(jsonObject);
                                calls.enqueue(new Callback<Result>() {
                                    @Override
                                    public void onResponse(Call<Result> call, Response<Result> response) {
                                        holder.like.setTextColor(Color.BLUE);
                                    }

                                    @Override
                                    public void onFailure(Call<Result> call, Throwable t) {

                                    }
                                });
                            }


                        }


                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                        }
                    });
                }
                else
                    Toast.makeText(context, "로그인해 주세요.", Toast.LENGTH_SHORT).show();

            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerView.setVisibility(View.GONE);
                reply_layout.setVisibility(View.VISIBLE);
                Post item = getItemAt(holder.getAdapterPosition());
                initReply(item);

            }
        });
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    public Post getItemAt(int position)
    {
        return postList.get(position);
    }
    public void addList(List<Post> add)
    {
        int addSize = add.size();
        for(int i=0;i<addSize;i++)
        {
            postList.add(add.get(i));
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView writer;
        public TextView date;
        public TextView click_number;//클릭이 아니라 좋아요 수
        public TextView reply_number;
        public TextView content;
        public TextView reply;
        public TextView like;
        public TextView cateText;
        public TextView title;
        public ViewHolder(View view)
        {
            super(view);

            writer = (TextView)view.findViewById(R.id.post_writer);
            date =(TextView)view.findViewById(R.id.post_date);
            click_number=(TextView)view.findViewById(R.id.post_click_number);
            content = (TextView)view.findViewById(R.id.post_content);
            reply = (TextView)view.findViewById(R.id.board_reply);
            like = (TextView)view.findViewById(R.id.board_like);
            title = (TextView)view.findViewById(R.id.post_title);
            cateText = (TextView)view.findViewById(R.id.post_category_text);
            reply_number = (TextView)view.findViewById(R.id.reply_number);
        }

    }


    public void initReply(Post item)
    {
        reply_current_page=1;
        p_user_id = SharedPrefereneces.get(context,"id");
        s_category=item.getCategory();
        s_title=item.getTitle();
        s_writer=item.getWriter();
        s_content = item.getContent();
        s_date = item.getDate();
        s_click_number=item.getClick_number();
        s_post_id=item.getPost_id();
        s_reply = item.getLikeCount();


        p_category=(TextView)reply_layout.findViewById(R.id.post_view_category);
        p_title=(TextView)reply_layout.findViewById(R.id.post_view_title);
        p_writer=(TextView)reply_layout.findViewById(R.id.post_view_writer);
        p_content=(TextView)reply_layout.findViewById(R.id.post_view_content);
        p_date =(TextView)reply_layout.findViewById(R.id.post_view_date);
        p_click_number=(TextView)reply_layout.findViewById(R.id.post_view_click_number);
        p_reply_more=(TextView)reply_layout.findViewById(R.id.post_view_reply_more);
        p_edit_reply=(EditText)reply_layout.findViewById(R.id.post_view_edit_reply);
        p_edit_ok=(Button)reply_layout.findViewById(R.id.post_view_edit_reply_btn_ok);
        p_reply_area=(LinearLayout)reply_layout.findViewById(R.id.post_view_reply_area);
        p_reply_number=(TextView)reply_layout.findViewById(R.id.post_view_click_number);

        if(p_reply_area.getChildCount()>0) {
            p_reply_area.removeAllViews();
        }

        if(ok==1)
            p_edit_reply.requestFocus();

        String cate="";
        if(s_category.equals("1"))
            s_category="육아고민";
        else
            s_category="잡담";
        p_category.setText(s_category);
        p_title.setText(s_title);
        p_writer.setText(s_writer);
        p_content.setText(s_content);
        p_date.setText(s_date);
        p_click_number.setText(s_click_number);

        p_reply_list= new ArrayList<>();

        callReply();

        p_reply_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callReply();
            }
        });
        p_edit_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String text = p_edit_reply.getText().toString();
                if(text.length()==0)
                    Toast.makeText(context, "내용을 작성해 주세요!", Toast.LENGTH_SHORT).show();
                else
                {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("post_id",s_post_id);
                    jsonObject.addProperty("writer",p_user_id);
                    jsonObject.addProperty("content",text);

                    ReplyService replyService = ReplyService.retrofit.create(ReplyService.class);
                    Call<Result> call =replyService.writeReply(jsonObject);
                    call.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            Toast.makeText(context, "작성 완료!", Toast.LENGTH_SHORT).show();
                            LinearLayout layout = (LinearLayout) LayoutInflater.from(context).inflate(R.layout.reply_list_item, null, false);
                            TextView reply_writer = (TextView)layout.findViewById(R.id.reply_writer);
                            TextView reply_date = (TextView)layout.findViewById(R.id.reply_date);
                            TextView reply_content = (TextView)layout.findViewById(R.id.reply_content);
                            reply_writer.setText(p_user_id);
                            reply_date.setText(new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").format(Calendar.getInstance().getTime()));
                            reply_content.setText(text);
                            p_reply_area.addView(layout,0);
                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                        }
                    });
                    p_edit_reply.setText("");
                }
            }
        });
    }

    void callReply()
    {
        ReplyService replyService = ReplyService.retrofit.create(ReplyService.class);
        Call<ReplyBody> call = replyService.listReply(s_post_id,reply_current_page);
        call.enqueue(new Callback<ReplyBody>() {
            @Override
            public void onResponse(Call<ReplyBody> call, Response<ReplyBody> response) {

                reply_current_page++;
                List<Reply> reply = response.body().getData();
                p_reply_list.addAll(reply);
                int dataSize = reply.size();

                for(int i=0;i<dataSize;i++) {
                    LinearLayout layout = (LinearLayout)LayoutInflater.from(context).inflate(R.layout.reply_list_item, null, false);
                    TextView reply_writer = (TextView)layout.findViewById(R.id.reply_writer);
                    TextView reply_date = (TextView)layout.findViewById(R.id.reply_date);
                    TextView reply_content = (TextView)layout.findViewById(R.id.reply_content);
                    reply_writer.setText(reply.get(i).getWriter());
                    reply_date.setText(reply.get(i).getTime());
                    reply_content.setText(reply.get(i).getContent());
                    p_reply_area.addView(layout);
                }
            }

            @Override
            public void onFailure(Call<ReplyBody> call, Throwable t) {

            }
        });
    }
}
