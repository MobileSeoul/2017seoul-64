package com.example.ktj.myapplication.activity;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;


import com.example.ktj.myapplication.R;

import com.example.ktj.myapplication.adapter.WebAdapter;

/**
 * Created by Dhyeok on 2017-10-29.
 */

public class CareWebListActivity extends AppCompatActivity {
    private ImageView iv_back;
    private RecyclerView recyclerView;
    private WebAdapter webAdapter;
    private ProgressBar progressBar;
    private LinearLayoutManager layoutManager;
    private int idx;
    private TextView tv_status_title;


    public void init() {
        tv_status_title = (TextView) findViewById(R.id.tv_status_title);
        tv_status_title.setText(getIntent().getStringExtra("title"));
        idx = Integer.parseInt(getIntent().getStringExtra("idx"));
        recyclerView = (RecyclerView) findViewById(R.id.rv);
        progressBar = (ProgressBar) findViewById(R.id.care_progressbar);
        layoutManager = new LinearLayoutManager(getApplicationContext());

        //back button
        iv_back = (ImageView) findViewById(R.id.back_image);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.care_web_list);

        init();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        webAdapter = new WebAdapter(getApplicationContext(), CareWebMainActivity.webList[idx]);
        recyclerView.setAdapter(webAdapter);
    }


}