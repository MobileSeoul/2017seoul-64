package com.example.ktj.myapplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.ViewTarget;
import com.example.ktj.myapplication.R;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by xowns on 2017-08-21.
 */

public class GuCategoryAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<String> imgList;
    private ArrayList<String> categoryList;
    LayoutInflater inflater;

    public GuCategoryAdapter(Context c, ArrayList<String> imgList) {
        mContext = c;
        this.imgList = imgList;
        inflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);

        categoryList = new ArrayList<String>(Arrays.asList("건강/의료", "공영주차장", "교육", "도서/문구",
                "도서관", "마트/식품", "문화/체육", "생활", "금융", "외식", "청소년시설",
                "출산/육아"));
    }

    @Override
    public int getCount() {
        return imgList.size();
    }

    @Override
    public Object getItem(int position) {
        return imgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

              View layout;

            layout = new View(mContext);

            layout = inflater.inflate(R.layout.gu_category_item, null);
            layout.setLayoutParams(new GridView.LayoutParams(parent.getWidth()/3, parent.getHeight()/ 3));

            ImageView category_img = (ImageView)layout.findViewById(R.id.img_category);
            TextView category_tv  = (TextView) layout.findViewById(R.id.tv_category);

            category_tv.setText(categoryList.get(position));

            Glide.with(mContext).load(imgList.get(position)).fitCenter().into(new ViewTarget<ImageView, GlideDrawable>(category_img) {
                @Override
                public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {

                    ImageView myView = this.view;
                    myView.setBackground(resource);
                }
            });

        return layout;
    }

}
