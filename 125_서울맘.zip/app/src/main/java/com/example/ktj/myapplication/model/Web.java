package com.example.ktj.myapplication.model;

import java.io.Serializable;

/**
 * Created by Dhyeok on 2017-10-29.
 */

public class Web {
    private String title;
    private String URL;

    public Web(String title, String URL) {
        setTitle(title);
        setURL(URL);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }
}
