package com.example.ktj.myapplication.activity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.model.Feed;
import com.example.ktj.myapplication.model.Place;

import java.lang.reflect.Array;
import java.util.ArrayList;

import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

/**
 * Created by xowns on 2017-08-22.
 */

public class FeedingRoomDetail extends AppCompatActivity {

    TextView subway_name, addr, week_time, saturday_time, holiday_time, tel,detail_name;
    ImageView feed_img,back_img;
    ArrayList<Feed> list;
    PhotoViewAttacher mAttacher;

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.feedingroom_detail);

        list = (ArrayList<Feed>) getIntent().getSerializableExtra("feedingroomInfo");
        subway_name = (TextView) findViewById(R.id.tv_subway);
        addr = (TextView) findViewById(R.id.tv_subway_addr);
        week_time = (TextView) findViewById(R.id.tv_weekday);
        saturday_time = (TextView) findViewById(R.id.tv_saturday);
        holiday_time = (TextView) findViewById(R.id.tv_hollyday);
        tel = (TextView) findViewById(R.id.tv_tel);
        feed_img = (ImageView) findViewById(R.id.iv_feedingroom);
        detail_name=(TextView)findViewById(R.id.detail_name);
        back_img=(ImageView)findViewById(R.id.back_image);


        back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        detail_name.setText(list.get(0).getSubway());
        subway_name.setText(list.get(0).getSubway());

        Glide.with(this).load(list.get(0).getMap()).into(feed_img);
        mAttacher = new PhotoViewAttacher(feed_img);//역내 수유실 지도 확대 기능
        mAttacher.setScaleType(ImageView.ScaleType.FIT_XY);

        addr.setText("주소 : " + list.get(0).getAddr());
        week_time.setText("평일 업무 시간 : " + list.get(0).getWeekday());
        saturday_time.setText("토요일 업무 시간 : " + list.get(0).getSaturday());
        holiday_time.setText("공휴일 업무 시간 : " + list.get(0).getHoliday());
        tel.setText("전화번호 : " + list.get(0).getTell());

    }
}
