package com.example.ktj.myapplication.activity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ktj.myapplication.R;

import java.io.IOException;
import java.util.List;

/**
 * Created by xowns on 2017-09-24.
 */

public class CategoryDetail extends AppCompatActivity implements View.OnClickListener {

    String img;
    String name;
    String address;
    String dial;
    String category;
    String support;

    Button btn1, btn2;
    TextView stCategory;
    TextView stName;
    TextView stAddress;
    TextView stDial;
    TextView stSupport;

    ImageView back_iamge;
    TextView detail_name;

    EditText editText;
    Button search;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.category_list_detail);

        btn1 = (Button) findViewById(R.id.btn_find_street); //길찾기
        btn2 = (Button) findViewById(R.id.btn_dial); //전화걸기

        stCategory = (TextView) findViewById(R.id.text_category);
        stName = (TextView)findViewById(R.id.text_name);
        stAddress = (TextView) findViewById(R.id.text_ad);
        stDial = (TextView) findViewById(R.id.text_dial);
        stSupport = (TextView)findViewById(R.id.text_support);
        detail_name=(TextView)findViewById(R.id.detail_name);
        back_iamge=(ImageView)findViewById(R.id.back_image);
        search = (Button)findViewById(R.id.btn_search);
        editText = (EditText)findViewById(R.id.edt_search);


        back_iamge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = editText.getText().toString();
                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+str));
                startActivity(intent);
            }
        });

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);

        Intent intent = getIntent();

       // img = intent.getExtras().getString("imgUrl");

        category = intent.getStringExtra("Category");
        stCategory.setText("분류 : " + category);


        name = intent.getExtras().getString("Name");
        stName.setText(name);
        detail_name.setText(category);
        editText.setHint(name);
        editText.setText(name);

       // getSupportActionBar().setTitle(name + " 상세 소개");

        address = intent.getStringExtra("Address");
        stAddress.setText(address);

        dial = intent.getStringExtra("Dial");
        stDial.setText(dial);

       support = intent.getStringExtra("Support");
        stSupport.setText(support);

    }


    @Override
    public void onClick(View v) {

        switch(v.getId()) {
            case R.id.btn_find_street: //길찾기

                //주소 -> 위도, 경도
                final Geocoder geocoder = new Geocoder(this);
                List<Address> list = null;
                double lat, lng;

                try{
                    list = geocoder.getFromLocationName(address, 5);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                lat = lng = 0.0;

                if(list != null) {
                    if(list.size() == 0) {
                        Toast.makeText(CategoryDetail.this, "해당되는 주소 정보가 없습니다.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Address position = list.get(0);
                        lat = position.getLatitude();
                        lng = position.getLongitude();
                    }
                }

                String Search_Url = "http://map.daum.net/link/to/" + name + "," + lat + ","
                        + lng;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Search_Url));
                startActivity(intent);
                break;

            case R.id.btn_dial: //전화걸기
                Intent intent3 = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+ dial));
                startActivity(intent3);
                break;
        }
    }
}