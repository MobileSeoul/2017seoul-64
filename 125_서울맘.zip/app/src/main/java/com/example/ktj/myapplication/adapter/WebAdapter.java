package com.example.ktj.myapplication.adapter;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.activity.CareContentActivity;
import com.example.ktj.myapplication.model.Article;
import com.example.ktj.myapplication.model.Web;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by dhyeok on 2017-08-07.
 */

public class WebAdapter extends RecyclerView.Adapter<WebAdapter.ViewHolder> {
    Context context;
    ArrayList<Web> list;

    public WebAdapter(Context context, ArrayList<Web> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //recycler view에 반복될 아이템 레이아웃 연결
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.care_web_item, null);
        return new ViewHolder(v);
    }

    public void addList(Web item) {
        list.add(item);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    /** 정보 및 이벤트 처리는 이 메소드에서 구현 **/

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Web webItem = list.get(position);

        holder.ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(webItem.getURL()));

                context.startActivity(intent);
            }
        });


        holder.tv_title.setText(webItem.getTitle());
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }


    /**
     * item layout 불러오기
     **/
    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout ll;
        TextView tv_title;

        public ViewHolder(View v) {
            super(v);
            ll = (LinearLayout) v.findViewById(R.id.ll);
            tv_title = (TextView) v.findViewById(R.id.tv_title);
        }
    }

}
