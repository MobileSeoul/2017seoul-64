package com.example.ktj.myapplication.activity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.adapter.ArticleAdapter;
import com.example.ktj.myapplication.listener.EndlessRecyclerOnScrollListener;
import com.example.ktj.myapplication.model.Article;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class CareListActivity extends AppCompatActivity {
    private ArrayList<Article> articleList;
    private RecyclerView recyclerView;
    private ArticleAdapter articleAdapter;
    private int page = 1;
    private ProgressBar progressBar;
    private boolean toast = true;
    private ImageView imageView;
    private TextView tv_status_title;


    String preURL = "http://iseoul.seoul.go.kr/portal/info/";
    String inURL;
    String postURL = "?pageIndex=";
    String URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.care_article_list);

        tv_status_title = (TextView) findViewById(R.id.tv_status_title);
        final int tabIdx = Integer.parseInt(getIntent().getStringExtra("tabIdx"));
        System.out.println("tabIdx = " + tabIdx);

        String title = "";

        if (tabIdx == 0) {
            inURL = "boyukNewsList.do";
            title = "보육뉴스";
        } else if (tabIdx == 1) {
            inURL = "boardHealthList.do";
            title = "육아상식";
        } else if (tabIdx == 2) {
            inURL = "boardBookList.do";
            title = "어린이 도서";
        }
        URL = preURL + inURL + postURL;
        tv_status_title.setText(title);

        recyclerView = (RecyclerView) findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        articleList = new ArrayList<>();
        articleAdapter = new ArticleAdapter(getApplicationContext(), articleList, tabIdx);
        recyclerView.setAdapter(articleAdapter);

        progressBar = (ProgressBar) findViewById(R.id.care_progressbar);
        imageView = (ImageView) findViewById(R.id.back_image);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        recyclerView.setOnScrollListener(new EndlessRecyclerOnScrollListener((LinearLayoutManager) recyclerView.getLayoutManager()) {
            @Override
            public void onLoadMore(int current_page) {
                progressBar.setVisibility(View.VISIBLE);
                page++;
                JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask();
                jsoupAsyncTask.setTabIdx(tabIdx);
                jsoupAsyncTask.execute();
            }
        });

        JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask();
        jsoupAsyncTask.setTabIdx(tabIdx);
        jsoupAsyncTask.execute();

    }



    private class JsoupAsyncTask extends AsyncTask<Void, Void, Void> {
        int tabIdx;

        void setTabIdx(int tabIdx){
            this.tabIdx = tabIdx;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                Document doc = Jsoup.connect(URL + page).get();
                Elements links = doc.select("table.boardTable").select("tbody").select("tr");

                for (Element link : links) {
                    try {
                        Article tmpArticle = new Article(link.child(0).text(), link.child(1).text(), link.child(3).text(), link.child(4).text(), link.child(1).child(0).toString().split("'")[1], this.tabIdx);

                        articleAdapter.addList(tmpArticle);
                        toast = true;
                    } catch (IndexOutOfBoundsException e) {
                        toast = false;
                    }
                }


            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            if (toast) {
                articleAdapter.notifyDataSetChanged();
            } else
                Toast.makeText(CareListActivity.this, "마지막 페이지입니다.", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
        }
    }

}


