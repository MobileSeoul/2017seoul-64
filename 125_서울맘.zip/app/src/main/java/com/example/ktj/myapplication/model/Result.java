package com.example.ktj.myapplication.model;

/**
 * Created by xyom on 2017-08-05.
 */

public class Result {
    String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
