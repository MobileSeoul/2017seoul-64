package com.example.ktj.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.RetroService.ReplyService;
import com.example.ktj.myapplication.model.Reply;
import com.example.ktj.myapplication.model.ReplyBody;
import com.example.ktj.myapplication.model.Result;
import com.example.ktj.myapplication.util.SharedPrefereneces;
import com.google.gson.JsonObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by xyom on 2017-08-05.
 */

public class PostViewActivity extends AppCompatActivity {

    int reply_current_page=1;

    TextView p_category,p_title,p_writer,p_content,p_date,p_click_number,p_reply_more;
    EditText p_edit_reply;
    Button p_edit_ok;
    LinearLayout p_reply_area;
    List<Reply> p_reply_list;
    String p_user_id="";

    String s_category,s_title,s_writer,s_content,s_date,s_click_number,s_post_id;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_view);


        p_user_id = SharedPrefereneces.get(PostViewActivity.this,"id");
        Intent intent = getIntent();
        s_category=intent.getStringExtra("category");
        s_title=intent.getStringExtra("title");
        s_writer=intent.getStringExtra("writer");
        s_content = intent.getStringExtra("content");
        s_date = intent.getStringExtra("date");
        s_click_number=intent.getStringExtra("click_number");
        s_post_id=intent.getStringExtra("post_id");


        p_category=(TextView)findViewById(R.id.post_view_category);
        p_title=(TextView)findViewById(R.id.post_view_title);
        p_writer=(TextView)findViewById(R.id.post_view_writer);
        p_content=(TextView)findViewById(R.id.post_view_content);
        p_date =(TextView)findViewById(R.id.post_view_date);
        p_click_number=(TextView)findViewById(R.id.post_view_click_number);
        p_reply_more=(TextView)findViewById(R.id.post_view_reply_more);
        p_edit_reply=(EditText)findViewById(R.id.post_view_edit_reply);
        p_edit_ok=(Button)findViewById(R.id.post_view_edit_reply_btn_ok);
        p_reply_area=(LinearLayout)findViewById(R.id.post_view_reply_area);

        if(intent.getIntExtra("reply",0)!=0)
            p_edit_reply.requestFocus();

        String cate="";
        if(s_category.equals("1"))
            s_category="육아고민";
        else
            s_category="잡담";
        p_category.setText(s_category);
        p_title.setText(s_title);
        p_writer.setText(s_writer);
        p_content.setText(s_content);
        p_date.setText(s_date);
        p_click_number.setText(s_click_number);

        p_reply_list= new ArrayList<>();

        callReply();

        p_reply_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callReply();
            }
        });
        p_edit_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String text = p_edit_reply.getText().toString();
                if(text.length()==0)
                    Toast.makeText(PostViewActivity.this, "내용을 작성해 주세요!", Toast.LENGTH_SHORT).show();
                else
                {
                    JsonObject jsonObject = new JsonObject();
                    jsonObject.addProperty("post_id",s_post_id);
                    jsonObject.addProperty("writer",p_user_id);
                    jsonObject.addProperty("content",text);

                    ReplyService replyService = ReplyService.retrofit.create(ReplyService.class);
                    Call<Result> call =replyService.writeReply(jsonObject);
                    call.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            Toast.makeText(PostViewActivity.this, "작성 완료!", Toast.LENGTH_SHORT).show();
                            LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.reply_list_item, null, false);
                            TextView reply_writer = (TextView)layout.findViewById(R.id.reply_writer);
                            TextView reply_date = (TextView)layout.findViewById(R.id.reply_date);
                            TextView reply_content = (TextView)layout.findViewById(R.id.reply_content);
                            reply_writer.setText(p_user_id);
                            reply_date.setText(new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").format(Calendar.getInstance().getTime()));
                            reply_content.setText(text);
                            p_reply_area.addView(layout,0);
                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                        }
                    });
                    p_edit_reply.setText("");
                }
            }
        });
    }

    void callReply()
    {
        ReplyService replyService = ReplyService.retrofit.create(ReplyService.class);
        Call<ReplyBody> call = replyService.listReply(s_post_id,reply_current_page);
        call.enqueue(new Callback<ReplyBody>() {
            @Override
            public void onResponse(Call<ReplyBody> call, Response<ReplyBody> response) {

                reply_current_page++;
                List<Reply> reply = response.body().getData();
                p_reply_list.addAll(reply);
                int dataSize = reply.size();

                for(int i=0;i<dataSize;i++) {
                    LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.reply_list_item, null, false);
                    TextView reply_writer = (TextView)layout.findViewById(R.id.reply_writer);
                    TextView reply_date = (TextView)layout.findViewById(R.id.reply_date);
                    TextView reply_content = (TextView)layout.findViewById(R.id.reply_content);
                    reply_writer.setText(reply.get(i).getWriter());
                    reply_date.setText(reply.get(i).getTime());
                    reply_content.setText(reply.get(i).getContent());
                    p_reply_area.addView(layout);
                }
            }

            @Override
            public void onFailure(Call<ReplyBody> call, Throwable t) {

            }
        });
    }
}
