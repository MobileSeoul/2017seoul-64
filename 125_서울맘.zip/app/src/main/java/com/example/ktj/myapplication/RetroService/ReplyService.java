package com.example.ktj.myapplication.RetroService;

import com.example.ktj.myapplication.model.PostBody;
import com.example.ktj.myapplication.model.ReplyBody;
import com.example.ktj.myapplication.model.Result;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by xyom on 2017-08-05.
 */

public interface ReplyService {

    String serverEndPoint = "http://52.79.231.100:3000";

    @GET("/reply/{post_id}/{page}")
    Call<ReplyBody> listReply(@Path("post_id") String post_id, @Path("page") int page);

    @Headers("Content-Type:application/json")
    @POST("/reply")
    Call<Result> writeReply(@Body JsonObject param);
    public static final Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(serverEndPoint)
            .addConverterFactory(GsonConverterFactory.create()).build();
}
