package com.example.ktj.myapplication.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.model.Place;

import java.util.List;

/**
 * Created by xowns on 2017-09-24.
 */

public class GuDetailAdapter extends ArrayAdapter<Place> {

    Activity activity;
    int resourece;

    public GuDetailAdapter(Context context, int resource, List<Place> objects) {
        super(context, resource, objects);

        activity = (Activity) context;
        this.resourece = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View itemView = convertView;

        if (itemView == null) {
            itemView = this.activity.getLayoutInflater().inflate(this.resourece, null);
        }

        Place item = getItem(position);

        if (item != null) {
            TextView tvName = (TextView) itemView.findViewById(R.id.tv_store_name);
            TextView tvAd = (TextView) itemView.findViewById(R.id.tv_address);
            TextView tvCategory = (TextView) itemView.findViewById(R.id.tv_category);

            tvName.setText(item.getCompanyName());
            tvAd.setText(item.getADDR());
            tvCategory.setText(item.getCATEGORY());
        }
        return itemView;
    }
}
