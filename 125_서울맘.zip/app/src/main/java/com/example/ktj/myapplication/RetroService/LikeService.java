package com.example.ktj.myapplication.RetroService;

import com.example.ktj.myapplication.model.LikeBody;
import com.example.ktj.myapplication.model.PostBody;
import com.example.ktj.myapplication.model.Result;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by xyom on 2017-08-05.
 */

public interface LikeService {
    String serverEndPoint = "http://52.79.231.100:3000";

    @GET("/likes/{user_id}/{post_id}")
    Call<Result> countPostLike(@Path("user_id") String user_id,@Path("post_id") String post_id);

    @GET("/likes/{user_id}")
    Call<LikeBody> listLike(@Path("user_id") String user_id);

    @Headers("Content-Type:application/json")
    @POST("/likes")
    Call<Result> doLike(@Body JsonObject param);

    @Headers("Content-Type:application/json")
    @DELETE("/likes/{user_id}/{post_id}")
    Call<Result> undoLike(@Path("user_id") String user_id,@Path("post_id") String post_id);

    public static final Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(serverEndPoint)
            .addConverterFactory(GsonConverterFactory.create()).build();
}
