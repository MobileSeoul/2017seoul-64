package com.example.ktj.myapplication.RetroService;

import com.example.ktj.myapplication.model.PostBody;
import com.example.ktj.myapplication.model.Result;
import com.example.ktj.myapplication.model.UserBody;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by xyom on 2017-09-01.
 */

public interface LoginService {
    String serverEndPoint = "http://52.79.231.100:3000";


    @GET("/users/{phone_number}")
    Call<UserBody> find(@Path("phone_number") String phone_number);

    @Headers("Content-Type:application/json")
    @POST("/users")
    Call<Result> writePost(@Body JsonObject param);

    public static final Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(serverEndPoint)
            .addConverterFactory(GsonConverterFactory.create()).build();
}
