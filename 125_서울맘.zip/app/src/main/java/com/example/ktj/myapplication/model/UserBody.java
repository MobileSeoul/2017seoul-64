package com.example.ktj.myapplication.model;

import java.util.List;

/**
 * Created by xyom on 2017-09-01.
 */

public class UserBody {
    String result;
    List<User> data;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<User> getData() {
        return data;
    }

    public void setData(List<User> data) {
        this.data = data;
    }
}
