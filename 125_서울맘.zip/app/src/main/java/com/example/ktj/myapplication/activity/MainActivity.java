package com.example.ktj.myapplication.activity;

import android.app.ProgressDialog;
import android.content.Intent;

import android.os.Build;

import android.os.AsyncTask;
import android.support.annotation.RequiresApi;
import android.graphics.Color;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.RetroService.PostService;
import com.example.ktj.myapplication.model.Result;
import com.example.ktj.myapplication.util.SharedPrefereneces;
import com.example.ktj.myapplication.adapter.BoardPostRecyclerAdapter;
import com.example.ktj.myapplication.adapter.FeedAdapter;
import com.example.ktj.myapplication.adapter.GuAdapter;
import com.example.ktj.myapplication.api.Api;
import com.example.ktj.myapplication.listener.EndlessRecyclerOnScrollListener;
import com.example.ktj.myapplication.model.Feed;
import com.example.ktj.myapplication.model.Like;
import com.example.ktj.myapplication.model.Place;
import com.example.ktj.myapplication.model.PostBody;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

public class MainActivity extends AppCompatActivity {
    CardView care_button[] = new CardView[4];
    int btnIdx;

    TabHost tabHost;
    RecyclerView boardRecyclerView;
    BoardPostRecyclerAdapter boardPostRecyclerAdapter;
    LinearLayout boardReplyView, writeLayout;
    ProgressDialog dialog;

    GridView gridView;//구 종류에 대한 gridview
    GuAdapter guAdapter;
    ArrayList<Place> place_list;
    ArrayList<Feed> feed_list;    //각 호선의 수유실 상세 정보
    ArrayList<Place>[] GuName;
    ArrayList<Feed>[] FeedName;

    TextView writeTextView, board_all, board_concern, board_etc;

    GridView gridView2;//역내 수유실에 대한 gridview
    FeedAdapter feedAdapter;

    AppCompatSpinner spinner;
    TextInputEditText title, content;
    AppCompatButton btn;

    //구 정보
    String gu_url = "http://xowns9418.cafe24.com/feedingroom/gu/";

    ArrayList<String> imgList = new ArrayList<String>(Arrays.asList(gu_url + "gang_nam.png", gu_url + "gang_dong.png",
            gu_url + "gang_buk.png", gu_url + "gang_sa.png", gu_url + "guna_ak.png", gu_url + "gung_gin.png", gu_url + "gu_ro.png",
            gu_url + "gum_choen.png", gu_url + "no_wan.png", gu_url + "do_bong.png", gu_url + "dong_dae_mun.png", gu_url + "dong_zak.png",
            gu_url + "ma_po.png", gu_url + "sa_dae_mun.png", gu_url + "sa_cho.png", gu_url + "sung_dong.png", gu_url + "sung_buk.png",
            gu_url + "song_pa.png", gu_url + "yang_choen.png", gu_url + "young_dung_po.png", gu_url + "young_san.png", gu_url + "en_pyhong.png",
            gu_url + "zong_ro.png", gu_url + "zung_gu.png", gu_url + "zung_rang.png", gu_url + "empty_img.png"));

    //수유실 있는 역 정보
    String subway_url = "http://xowns9418.cafe24.com/feedingroom/subway/";
    ArrayList<String> imgList2 = new ArrayList<String>(Arrays.asList(subway_url + "subway_line_1.png", subway_url + "subway_line_2.png", subway_url + "subway_line_1.png",
            subway_url + "subway_line_2.png", subway_url + "subway_line_1.png", subway_url + "subway_line_2.png", subway_url + "subway_line_1.png", subway_url + "subway_line_2.png", subway_url + "subway_line_1.png", subway_url + "subway_line_2.png", subway_url + "subway_line_3.png", subway_url + "subway_line_2.png",
            subway_url + "subway_line_3.png", subway_url + "subway_line_2.png", subway_url + "subway_line_3.png", subway_url + "subway_line_2.png", subway_url + "subway_line_3.png", subway_url + "subway_line_2.png",
            subway_url + "subway_line_3.png", subway_url + "subway_line_2.png", subway_url + "subway_line_3.png", subway_url + "subway_line_2.png", subway_url + "subway_line_4.png", subway_url + "subway_line_4.png",
            subway_url + "subway_line_4.png", subway_url + "subway_line_4.png"));

    List<Like> listLike;

    private int current_page = 0;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

    void callAllPost() {
        PostService postService = PostService.retrofit.create(PostService.class);
        Call<PostBody> call = postService.listPost(current_page);
        call.enqueue(new Callback<PostBody>() {
            @Override
            public void onResponse(Call<PostBody> call, Response<PostBody> response) {
                if (current_page == 1) // 처음일경우
                {
                    boardPostRecyclerAdapter = new BoardPostRecyclerAdapter(response.body().getData(), SharedPrefereneces.get(MainActivity.this, "id"), boardReplyView, boardRecyclerView);
                    boardRecyclerView.setAdapter(boardPostRecyclerAdapter);
                    boardRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    boardRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    boardRecyclerView.setOnScrollListener(new EndlessRecyclerOnScrollListener((LinearLayoutManager) boardRecyclerView.getLayoutManager()) {
                        @Override
                        public void onLoadMore(int p) {
                            current_page++;
                            callAllPost();
                        }
                    });
                } else // 갱신하는경우
                {
                    boardPostRecyclerAdapter.addList(response.body().getData());
                    boardPostRecyclerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<PostBody> call, Throwable t) {

            }
        });
    }

    void callCategoryPost(final int category) {
        PostService postService = PostService.retrofit.create(PostService.class);
        Call<PostBody> call = postService.listCategoryPost(category, current_page);
        call.enqueue(new Callback<PostBody>() {
            @Override
            public void onResponse(Call<PostBody> call, Response<PostBody> response) {
                if (current_page == 1) // 처음일경우
                {
                    boardPostRecyclerAdapter = new BoardPostRecyclerAdapter(response.body().getData(), SharedPrefereneces.get(MainActivity.this, "id"), boardReplyView, boardRecyclerView);
                    boardRecyclerView.setAdapter(boardPostRecyclerAdapter);
                    boardRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    boardRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    boardRecyclerView.setOnScrollListener(new EndlessRecyclerOnScrollListener((LinearLayoutManager) boardRecyclerView.getLayoutManager()) {
                        @Override
                        public void onLoadMore(int p) {
                            current_page++;
                            callCategoryPost(category);
                        }
                    });
                } else // 갱신하는경우
                {
                    boardPostRecyclerAdapter.addList(response.body().getData());
                    boardPostRecyclerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<PostBody> call, Throwable t) {

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        tabHost = (TabHost) findViewById(R.id.tabHost);
        tabHost.setup();

        boardRecyclerView = (RecyclerView) findViewById(R.id.board_recycler_view);
        boardReplyView = (LinearLayout) findViewById(R.id.board_reply_view);
        writeLayout = (LinearLayout) findViewById(R.id.write_layout);
        writeTextView = (TextView) findViewById(R.id.board_write);

        tabHost = (TabHost) findViewById(R.id.tabHost);
        tabHost.setup();

        writeTextView = (TextView) findViewById(R.id.board_write);
        gridView = (GridView) findViewById(R.id.gu_name);
        guAdapter = new GuAdapter(this, imgList);
        gridView2 = (GridView) findViewById(R.id.feed_name);
        feedAdapter = new FeedAdapter(this, imgList2);

        gridView.setAdapter(guAdapter);
        gridView2.setAdapter(feedAdapter);

        initCare();

        GuName = new ArrayList[26];
        FeedName = new ArrayList[26];


        dialog = new ProgressDialog(this); // 다이얼로그 띄우기

        for (int i = 0; i < 26; i++) //2차원 다시 초기화
        {
            GuName[i] = new ArrayList<>();
        }

        for (int i = 0; i < 26; i++) {
            FeedName[i] = new ArrayList<>();
        }

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //각 구에 대한 리스너 연결

                if(position == 25) return; // 구 종류의 마지막 빈 layout 안눌리게 하기

                Intent intent = new Intent(getApplication(), SelectGuActivity.class);
                intent.putExtra("guInfo", GuName[position]);
                startActivity(intent);

            }
        });

        gridView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //각 구에 대한 리스너 연결

                Intent intent2 = new Intent(getApplication(), FeedingRoomDetail.class);
                intent2.putExtra("feedingroomInfo", FeedName[position]);
                startActivity(intent2);
            }
        });
        boardRecyclerView = (RecyclerView) findViewById(R.id.board_recycler_view);
        writeTextView = (TextView) findViewById(R.id.board_write);
        board_all = (TextView) findViewById(R.id.board_all);
        board_concern = (TextView) findViewById(R.id.board_sad);
        board_etc = (TextView) findViewById(R.id.board_etc);

        TabHost.TabSpec ts1 = tabHost.newTabSpec("raiseInfo");
        ts1.setContent(R.id.content1);
        ts1.setIndicator("보육정보");
        tabHost.addTab(ts1);

        TabHost.TabSpec ts2 = tabHost.newTabSpec("board");
        ts2.setContent(R.id.content2);
        ts2.setIndicator("게시판");
        tabHost.addTab(ts2);

        TabHost.TabSpec ts3 = tabHost.newTabSpec("cardInfo");
        ts3.setContent(R.id.content3);
        ts3.setIndicator("다둥이 카드");
        tabHost.addTab(ts3);

        TabHost.TabSpec ts4 = tabHost.newTabSpec("find");
        ts4.setContent(R.id.content4);
        ts4.setIndicator("수유실 찾기");
        tabHost.addTab(ts4);

        tabHost.setOnTabChangedListener(new myTabChangeListener());
        writeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SharedPrefereneces.get(getApplicationContext(), "logined").equals("Y")) {
                    board_concern.setTextColor(Color.parseColor("#f7b0ba"));
                    board_all.setTextColor(Color.parseColor("#f7b0ba"));
                    board_etc.setTextColor(Color.parseColor("#f7b0ba"));
                    writeTextView.setTextColor(Color.parseColor("#ffffff"));
                    spinner.setSelection(0);
                    title.setText("");
                    content.setText("");
                    boardRecyclerView.setVisibility(View.GONE);
                    boardReplyView.setVisibility(View.GONE);
                    writeLayout.setVisibility(View.VISIBLE);
                } else {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivityForResult(intent, 100);
                }

            }
        });

        board_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boardRecyclerView.setVisibility(View.VISIBLE);
                boardReplyView.setVisibility(View.GONE);
                writeLayout.setVisibility(View.GONE);
                current_page = 1;
                board_all.setTextColor(Color.parseColor("#ffffff"));
                board_concern.setTextColor(Color.parseColor("#f7b0ba"));
                board_etc.setTextColor(Color.parseColor("#f7b0ba"));
                writeTextView.setTextColor(Color.parseColor("#f7b0ba"));
               callAllPost();
            }
        });
        board_concern.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boardRecyclerView.setVisibility(View.VISIBLE);
                boardReplyView.setVisibility(View.GONE);
                writeLayout.setVisibility(View.GONE);
                current_page = 1;
                board_concern.setTextColor(Color.parseColor("#ffffff"));
                board_all.setTextColor(Color.parseColor("#f7b0ba"));
                board_etc.setTextColor(Color.parseColor("#f7b0ba"));
                writeTextView.setTextColor(Color.parseColor("#f7b0ba"));
               callCategoryPost(1);
            }
        });
        board_etc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boardRecyclerView.setVisibility(View.VISIBLE);
                boardReplyView.setVisibility(View.GONE);
                writeLayout.setVisibility(View.GONE);
                current_page = 1;
                board_etc.setTextColor(Color.parseColor("#ffffff"));
                board_all.setTextColor(Color.parseColor("#f7b0ba"));
                board_concern.setTextColor(Color.parseColor("#f7b0ba"));
                writeTextView.setTextColor(Color.parseColor("#f7b0ba"));
                callCategoryPost(2);
            }
        });

        listLike = new ArrayList<>();
        initWrite();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK) {
            current_page = 1;
            board_all.setTextColor(Color.parseColor("#ffffff"));
            board_concern.setTextColor(Color.parseColor("#f7b0ba"));
            board_etc.setTextColor(Color.parseColor("#f7b0ba"));
            callAllPost();
        }
    }

    //첫번째 탭 이닛(케어 관련)
    public void initCare(){
        care_button[0] = (CardView) findViewById(R.id.bt1);
        care_button[1] = (CardView) findViewById(R.id.bt2);
        care_button[2] = (CardView) findViewById(R.id.bt3);
        care_button[3] = (CardView) findViewById(R.id.bt4);

        for (int i = 0; i < 3; i++) {
            btnIdx = i;

            care_button[i].setOnClickListener(new CardView.OnClickListener() {
                int tabIdx = btnIdx;

                @Override
                public void onClick(View view) { // TODO : click event } });
                    Intent intent = new Intent(MainActivity.this, CareListActivity.class);
                    intent.putExtra("tabIdx", Integer.toString(tabIdx));
                    startActivity(intent);
                }
            });
        }

        care_button[3].setOnClickListener(new CardView.OnClickListener() {

            @Override
            public void onClick(View view) { // TODO : click event } });
                Intent intent = new Intent(MainActivity.this, CareWebMainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void initWrite() {
        spinner = (AppCompatSpinner) findViewById(R.id.post_edit_spinner);
        title = (TextInputEditText) findViewById(R.id.post_edit_title);
        content = (TextInputEditText) findViewById(R.id.post_edit_content);
        btn = (AppCompatButton) findViewById(R.id.post_edit_ok);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String writer = SharedPrefereneces.get(MainActivity.this, "id");
                String ti = title.getText().toString();
                String cont = content.getText().toString();
                int category = spinner.getSelectedItemPosition() + 1;

                if (ti.equals(""))
                    Toast.makeText(MainActivity.this, "제목을 입력해 주세요", Toast.LENGTH_SHORT).show();
                else if (cont.equals(""))
                    Toast.makeText(MainActivity.this, "내용을 입력해 주세요", Toast.LENGTH_SHORT).show();
                else {

                    JsonObject postParams = new JsonObject();
                    postParams.addProperty("writer", writer);
                    postParams.addProperty("title", ti);
                    postParams.addProperty("content", cont);
                    postParams.addProperty("category", category);
                    PostService postService = PostService.retrofit.create(PostService.class);
                    Call<Result> call = postService.writePost(postParams);
                    call.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            Log.d("Success!!", call.isExecuted() + "");
                            board_all.performClick();
                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                        }
                    });
                }

            }
        });
    }


    @Override
    public void onBackPressed() {

        if (tabHost.getCurrentTabTag().equals("board")) {
            boardRecyclerView.setVisibility(View.VISIBLE);
            boardReplyView.setVisibility(View.GONE);
            board_all.performClick();
        }
    }

    class myTabChangeListener implements TabHost.OnTabChangeListener {

        @Override
        public void onTabChanged(String s) {
            switch (s) {
                case "raiseInfo":
                    break;
                case "board":

                    current_page = 1;
                    board_all.setTextColor(Color.parseColor("#ffffff"));
                    board_concern.setTextColor(Color.parseColor("#f7b0ba"));
                    board_etc.setTextColor(Color.parseColor("#f7b0ba"));

                    callAllPost();
                    break;
                case "cardInfo":

                    if (GuName[0].size() == 0) { //매번 api를 받아오지 않음
                        dialog();
                        fetchAsyncPost_Gu();//각 구에 해당하는 혜택가능한 지점 받아오기
                    }

                    break;
                case "find":

                    if (FeedName[0].size() == 0) {
                        fetchAsyncPost_Feed();//역내 수유실 정보 받아오기
                    }
                    break;
            }
        }

        void dialog() {

            dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            dialog.setMessage("데이터를 받고 있습니다...");
            dialog.show();
        }

        private void fetchAsyncPost_Gu() {

            FetchPostTask_Gu task = new FetchPostTask_Gu();
            FetchPostTask_Gu task2 = new FetchPostTask_Gu();
            FetchPostTask_Gu task3 = new FetchPostTask_Gu();
            FetchPostTask_Gu task4 = new FetchPostTask_Gu();

            task.execute(Api.Happy_Card_Url);
            task2.execute(Api.Happy_Card_Url2);
            task3.execute(Api.Happy_Card_Url3);
            task4.execute(Api.Happy_Card_Url4);
        }

        class FetchPostTask_Gu extends AsyncTask<String, Void, Place[]> {

            @Override
            protected Place[] doInBackground(String... params) {

                String Url = params[0];
                OkHttpClient client = new OkHttpClient();

                Request request = new Request.Builder().url(Url).build();

                try {
                    okhttp3.Response response = client.newCall(request).execute();

                    Gson gson = new Gson();
                    JsonParser parser = new JsonParser();
                    JsonReader jsonReader = new JsonReader(new StringReader(response.body().string()));

                    JsonElement rootObject = parser.parse(jsonReader).getAsJsonObject().get("InfoHappycard").getAsJsonObject().get("row");

                    Place places[] = gson.fromJson(rootObject, Place[].class);
                    return places;
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            protected void onPostExecute(Place places[]) {
                super.onPostExecute(places);
                //Log.d("FetchAsyncTASK",s);
                place_list = new ArrayList<>(Arrays.asList(places));
                city_parsing_gu();
                dialog.dismiss();
            }
        }

        void city_parsing_gu() {
            //Log.d("ARR", Arrays.toString(place_list.toArray()));

            for (int i = 0; i < place_list.size(); i++) {

                String category = place_list.get(i).getCATEGORY();
                String company_name = place_list.get(i).getCompanyName();
                String addr = place_list.get(i).getADDR();
                String office_tel = place_list.get(i).getOfficeTel();
                String support = place_list.get(i).getSUPPORT();

                String Gu = " ";
                try {
                    Gu = addr.split(" ")[1];

                } catch (Exception e) {

                }

                Place place = new Place(category, company_name, addr, office_tel, support);

                if (Gu.equals("강남구")) GuName[0].add(place);
                else if (Gu.equals("강동구")) GuName[1].add(place);
                else if (Gu.equals("강북구")) GuName[2].add(place);
                else if (Gu.equals("강서구")) GuName[3].add(place);
                else if (Gu.equals("관악구")) GuName[4].add(place);
                else if (Gu.equals("광진구")) GuName[5].add(place);
                else if (Gu.equals("구로구")) GuName[6].add(place);
                else if (Gu.equals("금천구")) GuName[7].add(place);
                else if (Gu.equals("노원구")) GuName[8].add(place);
                else if (Gu.equals("도봉구")) GuName[9].add(place);
                else if (Gu.equals("동대문구")) GuName[10].add(place);
                else if (Gu.equals("동작구")) GuName[11].add(place);
                else if (Gu.equals("마포구")) GuName[12].add(place);
                else if (Gu.equals("서대문구")) GuName[13].add(place);
                else if (Gu.equals("서초구")) GuName[14].add(place);
                else if (Gu.equals("성동구")) GuName[15].add(place);
                else if (Gu.equals("성북구")) GuName[16].add(place);
                else if (Gu.equals("송파구")) GuName[17].add(place);
                else if (Gu.equals("양천구")) GuName[18].add(place);
                else if (Gu.equals("영등포구")) GuName[19].add(place);
                else if (Gu.equals("용산구")) GuName[20].add(place);
                else if (Gu.equals("은평구")) GuName[21].add(place);
                else if (Gu.equals("종로구")) GuName[22].add(place);
                else if (Gu.equals("중구")) GuName[23].add(place);
                else if (Gu.equals("중랑구")) GuName[24].add(place);

            }
        }

        private void fetchAsyncPost_Feed() {

            FetchPostTask_Feed task = new FetchPostTask_Feed();

            task.execute(Api.Subway_Feedingroom);
        }

        class FetchPostTask_Feed extends AsyncTask<String, Void, Feed[]> {

            @Override
            protected Feed[] doInBackground(String... params) {

                String Url = params[0];
                OkHttpClient client = new OkHttpClient();

                Request request = new Request.Builder().url(Url).build();

                try {

                    okhttp3.Response response = client.newCall(request).execute();

                    Gson gson = new Gson();
                    JsonParser parser = new JsonParser();
                    JsonReader jsonReader = new JsonReader(new StringReader(response.body().string()));

                    JsonElement rootObject = parser.parse(jsonReader).getAsJsonObject().get("feed");

                    Feed feeds[] = gson.fromJson(rootObject, Feed[].class);

                    return feeds;
                } catch (IOException e) {
                    e.printStackTrace();

                    return null;
                }
            }

            protected void onPostExecute(Feed feeds[]) {
                super.onPostExecute(feeds);
                //Log.d("FetchAsyncTASK",s);
                feed_list = new ArrayList<>(Arrays.asList(feeds));
                city_parsing_feed();

            }
        }

        void city_parsing_feed() {
            //Log.d("ARR", Arrays.toString(place_list.toArray()));

            for (int i = 0; i < feed_list.size(); i++) {

                String subway = feed_list.get(i).getSubway();
                String map = feed_list.get(i).getMap();
                String addr = feed_list.get(i).getAddr();
                String weekday = feed_list.get(i).getWeekday();
                String saturday = feed_list.get(i).getSaturday();
                String hollyday = feed_list.get(i).getHoliday();
                String tell = feed_list.get(i).getTell();

                Feed feed = new Feed(subway, map, addr, weekday, saturday, hollyday, tell);

                if (feed.getSubway().equals("종로3가")) FeedName[0].add(feed);
                else if (feed.getSubway().equals("성수")) FeedName[1].add(feed);
                else if (feed.getSubway().equals("동대문")) FeedName[2].add(feed);
                else if (feed.getSubway().equals("강변")) FeedName[3].add(feed);
                else if (feed.getSubway().equals("시청")) FeedName[4].add(feed);
                else if (feed.getSubway().equals("잠실")) FeedName[5].add(feed);
                else if (feed.getSubway().equals("신설동")) FeedName[6].add(feed);
                else if (feed.getSubway().equals("삼성")) FeedName[7].add(feed);
                else if (feed.getSubway().equals("서울")) FeedName[8].add(feed);
                else if (feed.getSubway().equals("강남")) FeedName[9].add(feed);
                else if (feed.getSubway().equals("구파발")) FeedName[10].add(feed);
                else if (feed.getSubway().equals("신림")) FeedName[11].add(feed);
                else if (feed.getSubway().equals("독립문")) FeedName[12].add(feed);
                else if (feed.getSubway().equals("대림")) FeedName[13].add(feed);
                else if (feed.getSubway().equals("옥수")) FeedName[14].add(feed);
                else if (feed.getSubway().equals("영등포구청")) FeedName[15].add(feed);
                else if (feed.getSubway().equals("고속터미널")) FeedName[16].add(feed);
                else if (feed.getSubway().equals("신촌")) FeedName[17].add(feed);
                else if (feed.getSubway().equals("양재")) FeedName[18].add(feed);
                else if (feed.getSubway().equals("동대문역사")) FeedName[19].add(feed);
                else if (feed.getSubway().equals("도곡")) FeedName[20].add(feed);
                else if (feed.getSubway().equals("사당")) FeedName[21].add(feed);
                else if (feed.getSubway().equals("노원")) FeedName[22].add(feed);
                else if (feed.getSubway().equals("미아사거리")) FeedName[23].add(feed);
                else if (feed.getSubway().equals("길음")) FeedName[24].add(feed);
                else if (feed.getSubway().equals("이촌")) FeedName[25].add(feed);
            }
        }
    }
    }
