package com.example.ktj.myapplication.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by xyom on 2017-09-01.
 */

public class SharedPrefereneces {

    public static String get(Context context, String key) {
        SharedPreferences pref = context.getSharedPreferences("MOMS", 0);
        return pref.getString(key, "");
    }

    public static void put(Context context, String key, String value) {
        SharedPreferences pref = context.getSharedPreferences("MOMS", 0);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString(key, value);
        edit.commit();
    }
}
