package com.example.ktj.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.adapter.GuCategoryAdapter;
import com.example.ktj.myapplication.model.Place;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by xowns on 2017-08-21.
 */

public class SelectGuActivity extends AppCompatActivity {

    GridView gridView;
    GuCategoryAdapter adapter;
    TextView title;
    ArrayList<Place> list;
    ArrayList<Place>[] CategoryName;
    String Gu;

    String category_url = "http://xowns9418.cafe24.com/feedingroom/category/";
    ArrayList<String> imgListDetail = new ArrayList<String>(Arrays.asList(category_url + "health.png", category_url + "car_park.png", category_url + "education.png",
           category_url + "book.png", category_url + "library.png", category_url + "mart.png", category_url + "culture.png",
            category_url + "life.png", category_url + "money.png", category_url + "eat_out.png", category_url + "youth.png", category_url + "baby_care.png"));

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_city);

        list = (ArrayList<Place>) getIntent().getSerializableExtra("guInfo");

        CategoryName = new ArrayList[13];

        for(int i=0;i<13;i++) //2차원 다시 초기화
        {
            CategoryName[i] = new ArrayList<>();
        }

        Gu = " ";
        try {
                Gu = list.get(0).getADDR().split(" ")[1];

        }  catch (Exception e) {

        }

        title = (TextView)findViewById(R.id.gu_select_name);
        title.setText(Gu);

        gridView = (GridView)findViewById(R.id.gu_select);
        adapter = new GuCategoryAdapter(this, imgListDetail);
        gridView.setAdapter(adapter);
        category_parsing( );//categoty 파싱

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //각 구에 대한 리스너 연결

                //Toast.makeText(SelectGuActivity.this, CategoryName[position].get(0).getCATEGORY(), Toast.LENGTH_SHORT).show();
                if(CategoryName[position].size() == 0) {

                    Toast.makeText(SelectGuActivity.this, Gu + "에는 존재하지 않는 분류 입니다.", Toast.LENGTH_SHORT).show();
                }

                else {
                    Intent intent = new Intent(getApplication(), SelectCategory.class);
                    intent.putExtra("categoryInfo", CategoryName[position]);
                    startActivity(intent);
                }
            }
        });
    }

    void category_parsing( ) {

        for(int i=0; i<list.size(); i++) {

            String category = list.get(i).getCATEGORY();
            String company_name = list.get(i).getCompanyName();
            String addr = list.get(i).getADDR();
            String office_tel = list.get(i).getOfficeTel();
            String support = list.get(i).getSUPPORT();

            String category_name = " ";
            try {
                category_name = category.split(" ")[0];

            }  catch (Exception e) {

            }

            Place place = new Place(category, company_name, addr, office_tel, support);

            if (category_name.equals("건강/의료")) CategoryName[0].add(place);
            else if (category_name.equals("공영주차장")) CategoryName[1].add(place);
            else if (category_name.equals("교육")) CategoryName[2].add(place);
            else if (category_name.equals("도서/문구")) CategoryName[3].add(place);
            else if (category_name.equals("도서관")) CategoryName[4].add(place);
            else if (category_name.equals("마트/식품")) CategoryName[5].add(place);
            else if (category_name.equals("문화/체육")) CategoryName[6].add(place);
            else if (category_name.equals("생활")) CategoryName[7].add(place);
            else if (category_name.equals("생활/금융")) CategoryName[8].add(place);
            else if (category_name.equals("외식")) CategoryName[9].add(place);
            else if (category_name.equals("청소년시설")) CategoryName[10].add(place);
            else if (category_name.equals("출산/육아")) CategoryName[11].add(place);
        }
    }
}
