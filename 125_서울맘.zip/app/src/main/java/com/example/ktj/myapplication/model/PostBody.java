package com.example.ktj.myapplication.model;

import java.util.List;

/**
 * Created by xyom on 2017-08-05.
 */

public class PostBody {
    String result;
    List<Post> data;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<Post> getData() {
        return data;
    }

    public void setData(List<Post> data) {
        this.data = data;
    }
}
