package com.example.ktj.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.adapter.GuCategoryAdapter;
import com.example.ktj.myapplication.adapter.GuDetailAdapter;
import com.example.ktj.myapplication.model.Place;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xowns on 2017-08-21.
 */

public class SelectCategory extends AppCompatActivity implements View.OnClickListener{

    ListView guDetailList;
    ArrayList<Place> arrayList;
    GuDetailAdapter adapter;

    TextView tv;

    Button btnSearch;
    EditText editSearch;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_category);

        btnSearch = (Button) findViewById(R.id.btn_search);
        editSearch = (EditText) findViewById(R.id.edit_search);

        arrayList = (ArrayList<Place>) getIntent().getSerializableExtra("categoryInfo");
        tv = (TextView)findViewById(R.id.detail_name);
        tv.setText(arrayList.get(0).getCATEGORY());

        adapter = new GuDetailAdapter(this, R.layout.place_list_item, arrayList);
        guDetailList = (ListView) findViewById(R.id.gu_detail_listview);
        guDetailList.setAdapter(adapter);
        guDetailList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Place item = adapter.getItem(position);

                Intent intent = new Intent(SelectCategory.this, CategoryDetail.class);
                intent.putExtra("Name", item.getCompanyName()); // 이름
                intent.putExtra("Address", item.getADDR()); // 주소
                intent.putExtra("Dial", item.getOfficeTel()); // 전화번호
                intent.putExtra("Category", item.getCATEGORY()); // 분류
                intent.putExtra("Support", item.getSUPPORT());// 혜택
                startActivity(intent);
            }
        });

        btnSearch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()) {

            case R.id.btn_search:
                String search;
                boolean find;

                search = editSearch.getText().toString();
                find = false;

                for(int i=0; i< arrayList.size(); i++) {

                    if(arrayList.get(i).getCompanyName().equals(search)) {

                        Intent intent = new Intent(SelectCategory.this, CategoryDetail.class);
                        intent.putExtra("Name", arrayList.get(i).getCompanyName()); // 이름
                        intent.putExtra("Address", arrayList.get(i).getADDR()); // 주소
                        intent.putExtra("Dial", arrayList.get(i).getOfficeTel()); // 전화번호
                        intent.putExtra("Category", arrayList.get(i).getCATEGORY()); // 분류
                        intent.putExtra("Support", arrayList.get(i).getSUPPORT());// 혜택
                        startActivity(intent);

                        find = true;
                        break;
                    }
                }

                if(find == false)   Toast.makeText(SelectCategory.this, "존재하지 않는 데이터 입니다.", Toast.LENGTH_SHORT).show();
        }
    }
}
