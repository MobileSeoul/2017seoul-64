package com.example.ktj.myapplication.activity;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.RetroService.LoginService;
import com.example.ktj.myapplication.model.Result;
import com.example.ktj.myapplication.model.User;
import com.example.ktj.myapplication.model.UserBody;
import com.example.ktj.myapplication.util.Permission;
import com.example.ktj.myapplication.util.SharedPrefereneces;
import com.google.gson.JsonObject;

import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by xyom on 2017-09-01.
 */

public class LoginActivity extends AppCompatActivity {
    private final static int REQUEST_READ_PHONE_STATE_PERMISSION = 100;
    private final static int REQUEST_READ_SMS_STATE_PERMISSION = 200;

    TextView tv;
    LinearLayout ll;
    Button btn,send;
    EditText editText;
    String phoneNumber="";
    AppCompatActivity appCompatActivity;
    String confirmNumber="";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        appCompatActivity=this;

        tv = (TextView)findViewById(R.id.login_tv);
        btn = (Button)findViewById(R.id.login_btn);
        editText = (EditText)findViewById(R.id.edit_confirm);
        ll = (LinearLayout)findViewById(R.id.confirm_layout);
        send = (Button)findViewById(R.id.btn_send_sms);
        if(Permission.checkPermission(this, Manifest.permission.READ_PHONE_STATE, REQUEST_READ_PHONE_STATE_PERMISSION))
        {
            getPhoneNumber();
            LoginService loginService = LoginService.retrofit.create(LoginService.class);
            Call<UserBody> call =loginService.find(phoneNumber);
            call.enqueue(new Callback<UserBody>() {
                @Override
                public void onResponse(Call<UserBody> call, Response<UserBody> response) {
                    User user = response.body().getData().get(0);
                    String count = user.getCount();
                    final String user_id = user.getUser_id();
                    final String phone_number = user.getPhone_number();

                    if(count.equals("1"))
                    {
                        tv.setText("가입된 아이디 : "+user_id);
                        btn.setText("확인");
                        btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                SharedPrefereneces.put(LoginActivity.this,"logined","Y");
                                SharedPrefereneces.put(LoginActivity.this,"id",user_id);
                                SharedPrefereneces.put(LoginActivity.this,"phoneNumber",phone_number);
                                setResult(RESULT_OK,new Intent());
                                finish();
                            }
                        });


                    }
                }

                @Override
                public void onFailure(Call<UserBody> call, Throwable t) {

                }
            });
        }


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random r = new Random();
                int result = r.nextInt(10000)+1000;
                if(result>10000){
                    result = result - 1000;
                }
                confirmNumber=Integer.toString(result);
                if(Permission.checkPermission(appCompatActivity, Manifest.permission.SEND_SMS, REQUEST_READ_SMS_STATE_PERMISSION))
                    sendSMS(phoneNumber,confirmNumber);
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText("휴대폰 인증");
                btn.setText("확인");
                ll.setVisibility(View.VISIBLE);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String input = editText.getText().toString();

                        if(input.equals(confirmNumber))
                        {
                            tv.setText("아이디를 입력해 주세요.");
                            btn.setVisibility(View.GONE);
                            editText.setText("");
                            send.setText("확인");

                            send.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    if(editText.getText().toString().equals(""))
                                        Toast.makeText(LoginActivity.this, "아이디를 입력해 주세요", Toast.LENGTH_SHORT).show();
                                    else
                                    {
                                        JsonObject postParams = new JsonObject();
                                        postParams.addProperty("phone_number",phoneNumber);
                                        postParams.addProperty("user_id",editText.getText().toString());
                                        LoginService loginService = LoginService.retrofit.create(LoginService.class);

                                        Call<Result> call = loginService.writePost(postParams);
                                        call.enqueue(new Callback<Result>() {
                                            @Override
                                            public void onResponse(Call<Result> call, Response<Result> response) {
                                                String re = response.body().getResult();
                                                if(re.equals("1")) {
                                                    Toast.makeText(LoginActivity.this, "아이디가 중복됩니다.", Toast.LENGTH_SHORT).show();
                                                    editText.setText("");
                                                }
                                                else
                                                {
                                                    Toast.makeText(LoginActivity.this, "가입에 성공하였습니다.", Toast.LENGTH_SHORT).show();
                                                    SharedPrefereneces.put(appCompatActivity,"logined","Y");
                                                    SharedPrefereneces.put(appCompatActivity,"id",editText.getText().toString());
                                                    SharedPrefereneces.put(appCompatActivity,"phoneNumber",phoneNumber);
                                                    setResult(RESULT_OK,new Intent());
                                                    finish();
                                                }
                                            }

                                            @Override
                                            public void onFailure(Call<Result> call, Throwable t) {
                                                Toast.makeText(LoginActivity.this, "서버 오류", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                }
                            });
                        }
                        else if(input.equals(""))
                            Toast.makeText(LoginActivity.this, "인증번호를 입력하세요", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(LoginActivity.this, "인증번호가 다릅니다.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }

    private void getPhoneNumber() {
        TelephonyManager telephonyManager= (TelephonyManager)getSystemService(TELEPHONY_SERVICE);

        phoneNumber = telephonyManager.getLine1Number();
        Log.v("phoneNumber",phoneNumber);
        if(phoneNumber != null) {
            if(phoneNumber.charAt(0) == '+')
                phoneNumber = "0" + phoneNumber.substring(3);
            String str = phoneNumber.substring(0,3) + "-" + phoneNumber.substring(3, 7) + "-" + phoneNumber.substring(7, 11);
            tv.setText("휴대폰 번호:"+str);
        } else {
            tv.setText("존재하지 않음");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        // 권한 요청 결과
        if(requestCode == REQUEST_READ_PHONE_STATE_PERMISSION) {
            // 승인인 경우 번호 받아오기
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                getPhoneNumber();
                getPhoneNumber();
                LoginService loginService = LoginService.retrofit.create(LoginService.class);
                Call<UserBody> call =loginService.find(phoneNumber);
                call.enqueue(new Callback<UserBody>() {
                    @Override
                    public void onResponse(Call<UserBody> call, Response<UserBody> response) {
                        User user = response.body().getData().get(0);
                        String count = user.getCount();
                        String user_id = user.getUser_id();
                        String phone_number = user.getPhone_number();

                        if(count.equals("1"))
                        {
                            tv.setText("가입된 아이디 : "+user_id);
                            btn.setText("확인");
                            btn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    finish();
                                }
                            });
                            SharedPrefereneces.put(LoginActivity.this,"logined","Y");
                            SharedPrefereneces.put(LoginActivity.this,"id",user_id);
                            SharedPrefereneces.put(LoginActivity.this,"phoneNumber",phone_number);
                        }
                    }

                    @Override
                    public void onFailure(Call<UserBody> call, Throwable t) {

                    }
                });
            }
        }

        if(requestCode == REQUEST_READ_SMS_STATE_PERMISSION) {
            // 승인인 경우 번호 받아오기
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
                sendSMS(phoneNumber,confirmNumber);
        }
    }

    public void sendSMS(String smsNumber, String smsText){
        PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT_ACTION"), 0);
        PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED_ACTION"), 0);

        SmsManager mSmsManager = SmsManager.getDefault();
        mSmsManager.sendTextMessage(smsNumber, null, smsText, sentIntent, deliveredIntent);
    }
}
