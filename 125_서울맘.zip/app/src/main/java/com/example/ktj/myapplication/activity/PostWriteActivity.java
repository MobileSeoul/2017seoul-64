package com.example.ktj.myapplication.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatSpinner;

import com.example.ktj.myapplication.R;

/**
 * Created by xyom on 2017-08-05.
 */

public class PostWriteActivity extends AppCompatActivity {

    AppCompatSpinner spinner;
    TextInputEditText title,content;
    AppCompatButton btn;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_write);


    }
}
