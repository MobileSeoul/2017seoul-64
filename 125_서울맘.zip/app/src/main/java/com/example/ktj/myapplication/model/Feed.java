package com.example.ktj.myapplication.model;

import java.io.Serializable;

/**
 * Created by xowns on 2017-08-22.
 */

public class Feed implements Serializable {

    String subway; //역 이름
    String map;//역 내 지도
    String addr;
    String weekday;//평일 운영 시간
    String saturday;//토요일 운영시간
    String holiday;//휴일 운영시간
    String tell;//전화번호

    public Feed(String subway, String map, String addr, String weekday, String saturday, String holiday, String tell) {
        this.subway = subway;
        this.map = map;
        this.addr = addr;
        this.weekday = weekday;
        this.saturday = saturday;
        this.holiday = holiday;
        this.tell = tell;
    }

    public String getSubway() {
        return subway;
    }

    public void setSubway(String subway) {
        this.subway = subway;
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getWeekday() {
        return weekday;
    }

    public void setWeekday(String weekday) {
        this.weekday = weekday;
    }

    public String getSaturday() {
        return saturday;
    }

    public void setSaturday(String saturday) {
        this.saturday = saturday;
    }

    public String getHoliday() {
        return holiday;
    }

    public void setHoliday(String holiday) {
        this.holiday = holiday;
    }

    public String getTell() {
        return tell;
    }

    public void setTell(String tell) {
        this.tell = tell;
    }
}