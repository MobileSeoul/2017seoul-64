package com.example.ktj.myapplication.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.ktj.myapplication.R;
import com.example.ktj.myapplication.model.Article;
import com.example.ktj.myapplication.model.Web;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Dhyeok on 2017-10-29.
 */

public class CareWebMainActivity extends AppCompatActivity {

    //private ProgressBar progressBar;

    private ImageView iv_back;
    private CardView cv_btn[];
    public static ArrayList<Web> webList[];

    public void init() {

        //back button
        iv_back = (ImageView) findViewById(R.id.back_image);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //web list init
        webList = new ArrayList[3];
        for (int i = 0; i < 3; i++) {
            webList[i] = new ArrayList<>();
        }

        //menu 4btn
        cv_btn = new CardView[3];
        cv_btn[0] = (CardView) findViewById(R.id.bt1);
        cv_btn[1] = (CardView) findViewById(R.id.bt2);
        cv_btn[2] = (CardView) findViewById(R.id.bt3);

        JsoupAsyncTask jsoupAsyncTask = new JsoupAsyncTask();
        jsoupAsyncTask.execute();


    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.care_web_main);

        init();

        cv_btn[0].setOnClickListener(new CardView.OnClickListener() {

            @Override
            public void onClick(View view) { // TODO : click event } });
                Intent intent = new Intent(CareWebMainActivity.this, CareWebListActivity.class);

                intent.putExtra("title", "육아종합지원센터");
                intent.putExtra("idx", "0");
                startActivity(intent);
            }
        });
        cv_btn[1].setOnClickListener(new CardView.OnClickListener() {

            @Override
            public void onClick(View view) { // TODO : click event } });
                Intent intent = new Intent(CareWebMainActivity.this, CareWebListActivity.class);

                intent.putExtra("title", "장난감 도서관");
                intent.putExtra("idx", "1");
                startActivity(intent);
            }
        });
        cv_btn[2].setOnClickListener(new CardView.OnClickListener() {

            @Override
            public void onClick(View view) { // TODO : click event } });
                Intent intent = new Intent(CareWebMainActivity.this, CareWebListActivity.class);

                intent.putExtra("title", "학회 및 관련단체");
                intent.putExtra("idx", "2");
                startActivity(intent);
            }
        });


    }


    private class JsoupAsyncTask extends AsyncTask<Void, Void, Void> {

        String URL = "http://iseoul.seoul.go.kr/portal/info/relateSiteList.do";
        Document doc;
        Elements centerList;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {

            try {
                doc = Jsoup.connect(URL).get();
                centerList = doc.select(".center_list");

            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            int idx = 0;

            for (Element list : centerList) {

                Elements li_list = list.select("ul").select("li");

                for (Element li : li_list) {
                    Web tmp = new Web(li.text(), li.select("a").toString().split("\"")[1]);
                    webList[idx].add(tmp);
                }


                idx++;
            }


        }
    }
}