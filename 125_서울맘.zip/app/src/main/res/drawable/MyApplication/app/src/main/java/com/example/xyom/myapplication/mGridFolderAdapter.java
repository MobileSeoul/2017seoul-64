package com.example.xyom.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by xyom on 2016-10-28.
 */

public class mGridFolderAdapter extends BaseAdapter{

    Context context;
    int layout;
    mFolderData folder[];
    LayoutInflater inf;

    public mGridFolderAdapter(Context context, int layout, mFolderData[] folder) {
        this.context = context;
        this.layout = layout;
        this.folder = folder;
        inf = (LayoutInflater) context.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return folder.length;
    }

    @Override
    public Object getItem(int position) {
        return folder[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView==null) {
            convertView = inf.inflate(R.layout.mgrid_folder, null);

            viewHolder = new ViewHolder();
            viewHolder.img=(ImageView)convertView.findViewById(R.id.folder_image);
            viewHolder.tag=(TextView)convertView.findViewById(R.id.folder_tag);
            viewHolder.size=(TextView)convertView.findViewById(R.id.folder_contentSize);

            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder=(ViewHolder)convertView.getTag();
        }

        viewHolder.img.setImageBitmap(ImageHelper.getRoundedCornerBitmap(imageRotater.SafeDecodeBitmapFile(folder[position].imgPath),30));
        viewHolder.tag.setText("#"+folder[position].tag);
        viewHolder.size.setText("("+folder[position].size+")");


        return convertView;
    }

    class ViewHolder
    {
        public ImageView img;
        public TextView tag;
        public TextView size;
    }
}
