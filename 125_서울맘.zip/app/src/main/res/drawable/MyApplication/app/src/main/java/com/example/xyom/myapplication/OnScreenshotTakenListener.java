package com.example.xyom.myapplication;

import android.net.Uri;

public interface OnScreenshotTakenListener {
	void onScreenshotTaken(Uri uri);
}
