package com.example.xyom.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by xyom on 2016-10-26.
 */

class mgridAdapter extends BaseAdapter {
    Context context;
    int layout;
    SQLManager.content data[];
    LayoutInflater inf;

    public mgridAdapter(Context context, int layout, SQLManager.content data[]) {
        this.context = context;
        this.layout = layout;
        this.data = data;
        inf = (LayoutInflater) context.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.length;
    }

    @Override
    public Object getItem(int position) {
        return data[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView==null)
            convertView = inf.inflate(R.layout.grid_item, null);
        ImageView iv = (ImageView)convertView.findViewById(R.id.grid_image);
        iv.setImageBitmap(ImageHelper.getRoundedCornerBitmap(imageRotater.SafeDecodeBitmapFile(data[position].filepath),100));

        return convertView;
    }
}
