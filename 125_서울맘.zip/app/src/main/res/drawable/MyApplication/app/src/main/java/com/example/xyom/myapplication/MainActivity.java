package com.example.xyom.myapplication;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.FileObserver;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.provider.Browser;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.ExpandableListView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {


    final String serviceName = "com.example.xyom.myapplication.fileService";
    int isDrawerOpen=0;
    DrawerLayout mDrawerLayout;
    GridView mGrid;


    private ArrayList<SQLManager.content> dbData;
    private ArrayList<String> parentList;
    private HashMap<String,ArrayList<SQLManager.content>> childList;
    private mGridFolderAdapter mCustom;
    private int isShow=0;

    private ArrayList<mFolderData> mFolderDatas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(ContextCompat.checkSelfPermission(this,Manifest.permission.INTERNET)==PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.INTERNET},1);
        }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {

        }


        SQLManager sqlm = new SQLManager(MainActivity.this,"content.db",null,1);
        ArrayList<SQLManager.content> tempData = sqlm.SelectAll();
        for(int i=0;i<tempData.size();i++)
        {
            File file = new File(tempData.get(i).filepath);
            if(!file.exists())
            {
                sqlm.Delete(tempData.get(i).filepath);
            }
        } //file이 없으면 자동으로 삭제한다.

        dbData = sqlm.SelectAll(); // db의 값을 불러 온다.
        parentList = new ArrayList<String>();


        for(int i=0;i<dbData.size();i++)
        {
            if(!parentList.contains(dbData.get(i).tag))
            {
                parentList.add(dbData.get(i).tag);
            }
        } // 태그를 겹치지 않게 넣는다. 태그 별로 분류



        childList = new HashMap<String,ArrayList<SQLManager.content>>();

        for(int i=0;i<parentList.size();i++)
        {
            ArrayList<SQLManager.content> arr = new ArrayList<>();

            for(int j=0;j<dbData.size();j++)
            {
                if(parentList.get(i).equals(dbData.get(j).tag))
                {
                    arr.add(dbData.get(j));
                }
            }
            childList.put(parentList.get(i),arr);
        } // 태그별로, 태그가 같은 아이템의 파일 패스를 넣어준 해시맵을 만든다.


        mFolderDatas = new ArrayList<>();

        for(int i=0;i<parentList.size();i++)
        {
            mFolderData temp = new mFolderData();

            temp.imgPath=childList.get(parentList.get(i)).get(0).filepath; // childList의 첫번째 원소값을 무조건 가져온다..
            temp.tag=parentList.get(i);
            temp.size=childList.get(parentList.get(i)).size();

            mFolderDatas.add(temp);
        } // FolderList의 데이터 셋을 만들어 준다.

        mGrid = (GridView) findViewById(R.id.content_listview);
        mCustom = new mGridFolderAdapter(this,0,mFolderDatas.toArray(new mFolderData[mFolderDatas.size()]));
        mGrid.setAdapter(mCustom);
        mGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final ArrayList<SQLManager.content> arr = childList.get(parentList.get(i));
                mgridAdapter mgridAdapter = new mgridAdapter(MainActivity.this,0,arr.toArray(new SQLManager.content[arr.size()]));
                mGrid.setAdapter(mgridAdapter);
                mGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Log.d("url",arr.get(i).url);
                        String temp = arr.get(i).url;
                        String url=arr.get(i).url;
                        if(temp.contains("http://")||temp.contains("https://"))
                        {
                            url = temp.split("://")[1];
                        }
                        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("http://"+url));
                        startActivity(intent);
                    }
                });
                isShow=1;
            }
        });





        ImageButton imageButton = (ImageButton)findViewById(R.id.drawer_button);


        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(isDrawerOpen==0) {

                    mDrawerLayout.openDrawer(GravityCompat.START);
                    isDrawerOpen=1;
                }
                else {
                    mDrawerLayout.closeDrawer(GravityCompat.START);
                    isDrawerOpen=0;
                }
            }
        });


        Switch switch_link = (Switch)findViewById(R.id.switch_link);
        if(isServiceRunning(serviceName)) {
            Toast.makeText(this, "실행중", Toast.LENGTH_SHORT).show();
            switch_link.setChecked(true);
        }
        else
            switch_link.setChecked(false);


        switch_link.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true)
                {
                    Intent intent = new Intent(MainActivity.this,fileService.class);
                    intent.setFlags(Context.BIND_ADJUST_WITH_ACTIVITY);
                    startService(intent);
                }
                else
                {
                    Intent intent = new Intent(getApplicationContext(),fileService.class);
                    stopService(intent);
                }
            }
        });


    }

    @Override
    public void onBackPressed() {

        if(isShow==1)
        {
            mCustom = new mGridFolderAdapter(this,0,mFolderDatas.toArray(new mFolderData[mFolderDatas.size()]));
            mGrid.setAdapter(mCustom);
            mGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    final ArrayList<SQLManager.content> arr = childList.get(parentList.get(i));
                    mgridAdapter mgridAdapter = new mgridAdapter(MainActivity.this,0,arr.toArray(new SQLManager.content[arr.size()]));
                    mGrid.setAdapter(mgridAdapter);
                    mGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                            Log.d("url",arr.get(i).url);
                            String temp = arr.get(i).url;
                            String url=arr.get(i).url;
                            if(temp.contains("http://")||temp.contains("https://"))
                            {
                                url = temp.split("://")[1];
                            }
                            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("http://"+url));
                            startActivity(intent);
                        }
                    });
                    isShow=1;
                }
            });
            isShow=0;

        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {


        super.onResume();
    }


    public Boolean isServiceRunning(String serviceName) {
        ActivityManager activityManager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo runningServiceInfo :activityManager.getRunningServices(Integer.MAX_VALUE)) {

            if (serviceName.equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
