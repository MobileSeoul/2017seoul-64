package com.example.xyom.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Hong on 2016-08-30.
 */
public class SQLManager extends SQLiteOpenHelper {

    public SQLManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE screenshot ( url TEXT, tag TEXT, filepath TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public void Insert(String url,String tag, String filepath) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO screenshot VALUES ( '" + url + "', '" + tag + "', '" + filepath + "');");
    }


    public void Update(String url,String tag,String filepath,String oldtag)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("url",url);
        values.put("tag",tag);
        values.put("filepath",filepath);
        db.update("screenshot",values,"title=?",new String[]{oldtag});
    }

    public void Delete(String filepath) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM screenshot WHERE filepath='" + filepath + "';");
    }


    public ArrayList<content> SelectAll() {
        ArrayList<content> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM screenshot", null);
        while(cursor.moveToNext()) {
            String url = cursor.getString(0);
            String tag = cursor.getString(1);
            String filepath = cursor.getString(2);
            content c = new content(url,tag,filepath);
            list.add(c);
        }

        return list;
    }

    public class content {
        public String url;
        public String tag;
        public String filepath;

        public content(String url,String tag,String filepath) {
            this.url = url;
            this.tag = tag;
            this.filepath=filepath;
        }
    }
}
