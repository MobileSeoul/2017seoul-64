package com.example.xyom.myapplication;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.FileObserver;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by xyom on 2016-09-07.
 */
public class fileService extends Service {

    ScreenshotObserver sc;
    FileObserver fo;

    String filepath="a";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        HandlerThread handlerThread = new HandlerThread("content_observer");
        handlerThread.start();
        final Handler handler = new Handler(handlerThread.getLooper()) {

            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
            }
        };


        getContentResolver().registerContentObserver(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                true,
                new ContentObserver(handler) {
                    @Override
                    public boolean deliverSelfNotifications() {
                        Log.d("dd", "deliverSelfNotifications");
                        return true;
                    }

                    @Override
                    public void onChange(boolean selfChange) {
                        super.onChange(selfChange);
                    }

                    @Override
                    public void onChange(boolean selfChange, Uri uri) {

                        try {
                            Cursor mcursor = getContentResolver().query(uri, null, null, null, null );
                            //미디어 폴더 전체의 변화를 감지한다.
                            while(mcursor.moveToNext()); // while문을 통하여 cursor를 끝까지 옮긴다.

                            mcursor.moveToPrevious(); // 가장 끝에서 전이 가장 최근에 변화가 생긴  마지막 파일이 된다.
                            String paths = mcursor.getString(mcursor.getColumnIndex("_data"));
                            filepath=paths;

                            //스크린 샷인가??
                            if (paths.contains("Screenshots")) {
                                NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                                NotificationCompat.Builder builder = new NotificationCompat.Builder(fileService.this);

                                builder.setSmallIcon(R.drawable.take)
                                        .setColor(Color.argb(255,248,238,225))
                                        .setContentTitle("스크린샷 저장")
                                        .setContentText("url을 입력해주세요!")
                                        .setAutoCancel(true);

                                Intent intent = new Intent(getApplicationContext(),writeContentActivity.class);
                                intent.putExtra("filepath",filepath);
                                PendingIntent pintent = PendingIntent.getActivity(getApplicationContext(),0,intent,PendingIntent.FLAG_CANCEL_CURRENT);
                                builder.setContentIntent(pintent);
                                manager.notify(1,builder.build());

                            } else {
                                Toast.makeText(fileService.this, "스크린 샷이 아님", Toast.LENGTH_SHORT).show();
                            }
                        }catch(Exception e)
                       {
                            Log.d("No file","파일이 삭제됨");
                            e.printStackTrace();
                        }


                        super.onChange(selfChange, uri);
                    }
                }
        );
        return 0;
    }

    @Override
    public void onDestroy() {
        stopSelf();
        super.onDestroy();
    }
}
