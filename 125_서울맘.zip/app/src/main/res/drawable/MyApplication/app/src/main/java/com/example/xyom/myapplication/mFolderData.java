package com.example.xyom.myapplication;

/**
 * Created by xyom on 2016-10-28.
 */

public class mFolderData {
    String imgPath;
    String tag;
    int size;
}
